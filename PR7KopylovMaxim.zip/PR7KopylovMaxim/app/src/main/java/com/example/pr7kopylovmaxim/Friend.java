package com.example.pr7kopylovmaxim;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Friend extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.friend);
    }
}